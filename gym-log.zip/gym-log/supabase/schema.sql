-- Gym Log — Supabase schema
-- Run once in the Supabase dashboard: SQL Editor → New query → paste → Run.
-- Every row belongs to the signed-in user; Row Level Security keeps each user's data private.

-- ---------- tables ----------
-- Each record is stored as JSON (`data`) so the app can evolve without migrations.
-- Query example: select data->>'date' as date, (data->>'kg')::numeric as kg from bodyweight order by 1;

create table if not exists public.workouts (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  id         text not null,
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.templates (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  id         text not null,
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.bodyweight (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  id         text not null,
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.photos (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  id         text not null,
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

-- ---------- row level security ----------
do $$
declare t text;
begin
  foreach t in array array['workouts','templates','bodyweight','photos'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "own rows" on public.%I', t);
    execute format(
      'create policy "own rows" on public.%I for all to authenticated
         using ((select auth.uid()) = user_id)
         with check ((select auth.uid()) = user_id)', t);
  end loop;
end $$;

-- ---------- photo storage ----------
-- Private bucket; files live under <user id>/<photo id>.jpg and are shown through short-lived signed URLs.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('photos', 'photos', false, 10485760, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "gymlog photos read"   on storage.objects;
drop policy if exists "gymlog photos insert" on storage.objects;
drop policy if exists "gymlog photos update" on storage.objects;
drop policy if exists "gymlog photos delete" on storage.objects;

create policy "gymlog photos read" on storage.objects for select to authenticated
  using (bucket_id = 'photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "gymlog photos insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "gymlog photos update" on storage.objects for update to authenticated
  using (bucket_id = 'photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "gymlog photos delete" on storage.objects for delete to authenticated
  using (bucket_id = 'photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
