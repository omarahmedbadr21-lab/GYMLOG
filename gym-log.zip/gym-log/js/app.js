import * as store from './store.js';

/* ============ helpers ============ */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone = o => JSON.parse(JSON.stringify(o));
const uid = p => (p||'') + Date.now().toString(36) + Math.random().toString(36).slice(2,6);
const pad = n => String(n).padStart(2,'0');
const today = () => { const d=new Date(); return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); };
const pd = s => { const [y,m,d]=(s||today()).split('-').map(Number); return new Date(y,m-1,d); };
const DAYS=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const MONL=['January','February','March','April','May','June','July','August','September','October','November','December'];
const fmtDate = s => { const d=pd(s); return DAYS[d.getDay()].slice(0,3)+' '+d.getDate()+' '+MON[d.getMonth()]; };
const fmtN = n => (n==null||isNaN(n)) ? '–' : Number(n).toLocaleString('en-US',{maximumFractionDigits:1});
const num = v => { if(v===''||v==null) return null; const n=parseFloat(String(v).replace(',','.').replace('−','-')); return isNaN(n)?null:n; };
const key = n => String(n||'').trim().toLowerCase().replace(/\s+/g,' ');
const signed = k => (k>0?'+':'−')+fmtN(Math.abs(k));
const GROUPS = ['Main','Finishers','Optional'];
const GLABEL = {Main:'Main',Finishers:'Low-weight finishers',Optional:'Optional'};
const unitLabel = u => u==='min'?'min':u==='sec'?'sec':'reps';
function setPath(o,path,v){ const p=path.split('.'); let c=o; for(let i=0;i<p.length-1;i++){ c=c[p[i]]; if(c==null) return; } c[p[p.length-1]]=v; }
function toast(msg){ const t=document.createElement('div'); t.className='toast'; t.textContent=msg; document.body.appendChild(t); setTimeout(()=>t.remove(),1800); }

/* targets: 3 sets x 10 reps (older data stored "3x10" as text) */
function normEx(e){
  if(e.targetSets==null && e.targetReps==null){
    const m=String(e.target||'').match(/(\d+)\s*[x×]\s*([\d.]+)/i);
    if(m){ e.targetSets=+m[1]; e.targetReps=+m[2]; }
    else if(e.unit==='reps'){ const t=String(e.target||'').match(/(\d+)\s*sets?/i); if(t){ e.targetSets=+t[1]; e.targetReps=null; } }
    else { const t=String(e.target||'').match(/([\d.]+)\s*(min|sec|s)?/i);
      if(t){ let v=+t[1]; const u=(t[2]||'').toLowerCase(); if(e.unit==='sec'&&u==='min') v*=60; if(e.unit==='min'&&(u==='sec'||u==='s')) v=Math.round(v/60*10)/10; e.targetSets=1; e.targetReps=v; } }
  }
  delete e.target;
  if(e.bw==null) e.bw=false;
  if(!e.unit) e.unit='reps';
  return e;
}
function normalize(coll,row){ if(coll==='workouts'||coll==='templates'){ row.exercises=(row.exercises||[]).map(normEx); } return row; }
const targetStr = e => (e.unit!=='reps') ? ((e.targetSets>1?e.targetSets+'×':'')+(e.targetReps??'')+' '+e.unit) : ((e.targetSets??'?')+'x'+(e.targetReps??'?'));

/* ============ state + storage ============ */
const S = { workouts:[], templates:[], photos:[], bodyweight:[], mode:'loading', route:{name:'log'},
  draft:null, tdraft:null, progEx:null, progMetric:null, photoFilter:'all', comparing:false, cmpSel:[], bwMode:'weekly', banner:'' };
const COLLS=store.COLLS;

function setSync(state,text){ const el=$('#sync'); if(el) el.innerHTML='<span class="dot '+state+'"></span><span>'+esc(text)+'</span>'; }
function showStatus(){
  const st=store.getStatus();
  if(S.mode!=='app'){ setSync('',''); return; }
  if(!st.online) setSync('err', st.pending? st.pending+' unsynced · offline' : 'Offline');
  else if(st.state==='error') setSync('err','Sync error — retrying');
  else if(st.pending || st.state==='saving') setSync('busy','Saving…');
  else setSync('ok','Synced');
}
function refreshFromStore(){ COLLS.forEach(c=>{ S[c]=store.rows(c).map(r=>normalize(c,r)); }); }
store.onChange(()=>{ refreshFromStore(); showStatus(); onData(); });

function strip(o){ const c=clone(o); delete c.id; return c; }
function put(coll,id,data){
  const body=strip(data);
  const arr=S[coll]; const i=arr.findIndex(x=>x.id===id); const row=Object.assign({id},clone(body));
  if(i>=0) arr[i]=row; else arr.push(row);
  store.put(coll,id,body);
  return Promise.resolve();
}
async function del(coll,id){ S[coll]=S[coll].filter(x=>x.id!==id); store.del(coll,id); }

/* image handling: photos live in Supabase Storage, shown through short-lived signed URLs */
const BLANK='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
const imgSrc = p => (p._preview || BLANK);
const imgAttr = p => p.path ? ' data-path="'+esc(p.path)+'"' : '';
async function hydrateImages(root){
  const els=[...(root||document).querySelectorAll('img[data-path]')]; if(!els.length) return;
  const urls=await store.photoUrls(els.map(e=>e.dataset.path));
  els.forEach(e=>{ const u=urls[e.dataset.path]; if(u && e.src!==u) e.src=u; else if(!u) e.classList.add('noimg'); });
}
async function shrink(file,max,q){
  const url=URL.createObjectURL(file);
  try{
    const img=await new Promise((res,rej)=>{const i=new Image(); i.onload=()=>res(i); i.onerror=rej; i.src=url;});
    const s=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));
    const c=document.createElement('canvas'); c.width=Math.round(img.naturalWidth*s); c.height=Math.round(img.naturalHeight*s);
    c.getContext('2d').drawImage(img,0,0,c.width,c.height);
    return await new Promise(r=>c.toBlob(r,'image/jpeg',q));
  } finally { URL.revokeObjectURL(url); }
}
async function storeImage(file,id){
  const blob=await shrink(file,1600,0.85);
  return {path: await store.uploadPhoto(blob,id)};
}
function pickFile(accept){ return new Promise(res=>{ const f=$('#file'); f.accept=accept||'image/*'; f.value=''; f.onchange=()=>res(f.files[0]||null); f.click(); }); }

/* ============ body weight + load ============ */
const bwSorted = () => S.bodyweight.filter(b=>num(b.kg)).sort((a,b)=>a.date.localeCompare(b.date));
function bwOn(date){ const l=bwSorted(); if(!l.length) return null; let r=null; for(const b of l){ if(b.date<=date) r=b; } return num((r||l[0]).kg); }
const wBW = w => num(w.bodyWeight) ?? bwOn(w.date);
const setLoad = (s,e,bw) => e.bw ? ((bw||0)+(num(s.kg)||0)) : (num(s.kg)||0);
function weekAnchor(){
  let a=null;
  S.workouts.forEach(w=>{ if(!w.date) return; const t=pd(w.date).getTime()-(+w.week||0)*7*864e5; if(a==null||t<a) a=t; });
  if(a==null){ const b=S.bodyweight.map(x=>x.date).sort()[0]; a=pd(b||today()).getTime(); }
  return a;
}
const programWeek = date => Math.floor(Math.round((pd(date).getTime()-weekAnchor())/864e5)/7);

/* exercise stats */
const doneSets = ex => (ex.sets||[]).filter(s => num(s.reps)>0);
const isDone = ex => doneSets(ex).length>0;
const exVolume = (ex,bw) => ex.unit!=='reps' ? 0 : doneSets(ex).reduce((a,s)=>a+setLoad(s,ex,bw)*(num(s.reps)||0),0);
const wVolume = w => { const bw=wBW(w); return (w.exercises||[]).reduce((a,e)=>a+exVolume(e,bw),0); };
const wSets = w => (w.exercises||[]).reduce((a,e)=>a+doneSets(e).length,0);
const wExDone = w => (w.exercises||[]).filter(isDone).length;
function setStr(s,e,bw){
  const r=num(s.reps), k=num(s.kg); const reps=(r!=null?fmtN(r):'–'); let out;
  if(e.unit!=='reps') out = r!=null? fmtN(r)+' '+e.unit : '';
  else if(e.bw){ const adj=k?signed(k):''; out = bw ? fmtN(bw+(k||0))+'×'+reps+(adj?' (BW'+adj+')':'') : 'BW'+adj+'×'+reps; }
  else out=(k? fmtN(k)+'×':'')+reps;
  if(s.note) out+=' '+s.note;
  return out.trim();
}

/* ============ derived ============ */
const byDateDesc = (a,b)=> (b.date||'').localeCompare(a.date||'') || (b.createdAt||0)-(a.createdAt||0);
function lastSets(name, beforeDate, excludeId){
  const k=key(name); if(!k) return null;
  const ws=S.workouts.filter(w=>w.id!==excludeId && (w.date||'')<=(beforeDate||'9999')).sort(byDateDesc);
  for(const w of ws){ const e=(w.exercises||[]).find(e=>key(e.name)===k && isDone(e)); if(e) return {date:w.date, sets:doneSets(e), e, bw:wBW(w)}; }
  return null;
}
function allNames(){ const m=new Map(); S.templates.forEach(t=>(t.exercises||[]).forEach(e=>{ if(e.name&&!m.has(key(e.name))) m.set(key(e.name),e.name.trim()); })); S.workouts.forEach(w=>(w.exercises||[]).forEach(e=>{ if(e.name&&!m.has(key(e.name))) m.set(key(e.name),e.name.trim()); })); return [...m.values()].sort(); }
function refreshDatalist(){ $('#exnames').innerHTML=allNames().map(n=>'<option value="'+esc(n)+'">').join(''); }

/* ============ render ============ */
let charts=[];
function killCharts(){ charts.forEach(c=>c.destroy()); charts=[]; }
function onData(){
  if(S.mode!=='app') return;
  refreshDatalist();
  if(S.route.name==='workout' || S.route.name==='template') return; // keep drafts stable while editing
  render();
}
function render(){
  killCharts();
  document.body.classList.toggle('noapp', S.mode!=='app');
  document.querySelectorAll('nav.tabs button').forEach(b=>b.classList.toggle('on', b.dataset.tab===({workout:'log',template:'routines'}[S.route.name]||S.route.name)));
  const banner = S.banner ? '<div class="banner">'+esc(S.banner)+'</div>' : '';
  const v=$('#view');
  if(S.mode==='loading'){ v.innerHTML='<div class="empty"><span class="spin"></span></div>'; return; }
  if(S.mode==='noconfig'){ v.innerHTML=vNoConfig(); return; }
  if(S.mode==='auth'){ v.innerHTML=vAuth(); return; }
  const r=S.route.name;
  v.innerHTML = banner + (r==='log'?vLog(): r==='progress'?vProgress(): r==='body'?vBody(): r==='routines'?vRoutines(): r==='workout'?vWorkout(): r==='template'?vTemplate(): '');
  if(r==='progress'||r==='body') drawCharts();
  hydrateImages(v);
}

/* ---- Log ---- */
function bwThisWeek(){ const wk=programWeek(today()); return S.bodyweight.filter(b=>num(b.kg)&&programWeek(b.date)===wk).sort((a,b)=>b.date.localeCompare(a.date))[0]||null; }
function bwQuickForm(){
  const wk=programWeek(today()); const last=bwSorted().slice(-1)[0];
  return '<div class="card" style="margin-top:12px"><div class="row" style="margin-bottom:8px"><b>Week '+wk+' body weight</b><span class="sp"></span>'+(last?'<span class="muted small">last: '+fmtN(last.kg)+' kg · '+fmtDate(last.date)+'</span>':'')+'</div><div class="bwform"><div class="field"><label>Date</label><input class="in" type="date" id="bwdate" value="'+today()+'"></div><div class="field"><label>Weight (kg)</label><input class="in" id="bwkg" inputmode="decimal" placeholder="'+(last?fmtN(last.kg):'80')+'"></div><button class="btn pri" data-act="bwsave" style="padding:10px 16px">Save</button></div></div>';
}
function vLog(){
  const ws=[...S.workouts].sort(byDateDesc);
  let h='<div class="row" style="margin-top:16px"><button class="btn pri block" data-act="startmenu" style="padding:13px">+ Start workout</button></div>';
  if(!bwThisWeek()) h+=bwQuickForm();
  if(!ws.length) return h+'<div class="empty">No workouts yet. Start one from a routine or a blank page.</div>';
  const weeks=new Map(); ws.forEach(w=>{ const k=+w.week||0; if(!weeks.has(k)) weeks.set(k,[]); weeks.get(k).push(w); });
  [...weeks.keys()].sort((a,b)=>b-a).forEach(k=>{
    const list=weeks.get(k); const vol=list.reduce((a,w)=>a+wVolume(w),0); const sets=list.reduce((a,w)=>a+wSets(w),0);
    h+='<div class="weekhead"><h2>Week '+k+'</h2><span class="muted small">'+list.length+' session'+(list.length>1?'s':'')+' · '+sets+' sets · '+fmtN(vol)+' kg</span></div>';
    list.forEach(w=>{ const d=pd(w.date); const nPh=S.photos.filter(p=>p.workoutId===w.id).length;
      h+='<div class="card wcard" data-act="openw" data-id="'+w.id+'"><div class="daybox"><div class="m">'+DAYS[d.getDay()].slice(0,3)+'</div><div class="d">'+d.getDate()+'</div><div class="m">'+MON[d.getMonth()]+'</div></div><div style="flex:1;min-width:0"><h3>'+esc(w.title||'Workout')+'</h3><div class="muted small">'+wExDone(w)+' exercises · '+wSets(w)+' sets · '+fmtN(wVolume(w))+' kg'+(w.duration?' · '+esc(w.duration):'')+(nPh?' · '+nPh+' 📷':'')+'</div></div><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6B727B" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></div>'; });
  });
  return h;
}
function startMenu(){
  const ts=[...S.templates].sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  sheet('<h3>Start workout</h3><div class="menu">'+ts.map(t=>'<button class="btn" data-act="startt" data-id="'+t.id+'">'+esc(t.name)+' <span class="muted small" style="margin-left:auto">'+(t.exercises||[]).length+' exercises</span></button>').join('')+'<button class="btn ghost" data-act="startblank">Blank workout</button></div><p class="muted small" style="margin-top:12px">Starting from a routine pre-fills each set with the weight you used last time.</p>');
}
function blankSets(n,last){ return Array.from({length:n},(_,k)=>{ const ls=last&&last.sets.length?(last.sets[k]||last.sets[last.sets.length-1]):null; return {kg: ls? num(ls.kg) : null, reps:null, note:''}; }); }
function newWorkout(t){
  const date=today();
  const exercises = t ? (t.exercises||[]).map(e0=>{ const e=normEx(clone(e0));
    const last=lastSets(e.name,date,null); const n=num(e.targetSets) || (e.unit!=='reps'?1:3);
    return {name:e.name, group:e.group||'Main', alt:!!e.alt, bw:!!e.bw, targetSets:e.targetSets??n, targetReps:e.targetReps??(e.unit==='reps'?10:null), unit:e.unit||'reps', note:e.note||'', sets:blankSets(n,last)};
  }) : [];
  const w={id:uid('w'), date, week:S.workouts.length?programWeek(date):0, title:t?t.name:'Workout', duration:'', bodyWeight:bwOn(date), notes:'', templateId:t&&t.id?t.id:null, createdAt:Date.now(), exercises};
  closeSheet(); openWorkout(w,true);
}
function openWorkout(w,isNew){ S.draft=clone(w); S.route={name:'workout',id:w.id}; render(); window.scrollTo(0,0); if(isNew) put('workouts',S.draft.id,S.draft); }

/* ---- Workout editor ---- */
const dots='<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>';
function vWorkout(){
  const w=S.draft; if(!w) return '';
  const hasBW=w.exercises.some(e=>e.bw);
  let h='<div class="backbar"><button class="btn sm ghost" data-act="back">‹ Log</button><span class="sp"></span><button class="btn sm" data-act="copytext">Copy as text</button><button class="iconbtn" data-act="wmenu" aria-label="More">'+dots+'</button></div>';
  h+='<div class="card"><div class="field" style="margin-bottom:10px"><label>Title</label><input class="in" data-s="w" data-f="title" value="'+esc(w.title)+'" style="font-size:18px;font-weight:600"></div>';
  h+='<div class="hgrid"><div class="field"><label>Date · <span id="dayname">'+DAYS[pd(w.date).getDay()]+'</span></label><input class="in" type="date" data-s="w" data-f="date" value="'+esc(w.date)+'"></div><div class="field"><label>Week</label><input class="in" inputmode="numeric" data-s="w" data-f="week" data-t="num" value="'+esc(w.week)+'"></div>';
  h+='<div class="field"><label>Duration</label><input class="in" data-s="w" data-f="duration" value="'+esc(w.duration)+'" placeholder="e.g. 2 hrs"></div><div class="field"><label>Body weight (kg)</label><input class="in" inputmode="decimal" data-s="w" data-f="bodyWeight" data-t="num" value="'+esc(w.bodyWeight??'')+'" placeholder="'+(bwOn(w.date)!=null?fmtN(bwOn(w.date)):'kg')+'"></div></div>';
  if(hasBW && wBW(w)==null) h+='<div class="help" style="color:#f3c98a">Add your body weight so pull-ups, dips and other body-weight exercises count their real load.</div>';
  h+='</div>';
  const order=[...GROUPS, ...[...new Set(w.exercises.map(e=>e.group))].filter(g=>!GROUPS.includes(g))];
  order.forEach(g=>{
    const idx=w.exercises.map((e,i)=>({e,i})).filter(x=>(x.e.group||'Main')===g);
    if(!idx.length && g!=='Main') return;
    h+='<div class="grp"><div class="gh"><h2>'+esc(GLABEL[g]||g)+'</h2></div>';
    let n=0;
    idx.forEach(({e,i})=>{ if(!e.alt) n++; h+=exCard(e,i,e.alt?'OR':n); });
    h+='<button class="btn sm ghost" data-act="addex" data-g="'+esc(g)+'">+ Add exercise</button></div>';
  });
  const missing=GROUPS.filter(g=>!w.exercises.some(e=>(e.group||'Main')===g) && g!=='Main');
  if(missing.length) h+='<div class="row wrap2" style="margin-top:14px">'+missing.map(g=>'<button class="btn sm ghost" data-act="addex" data-g="'+g+'">+ '+GLABEL[g]+' exercise</button>').join('')+'</div>';
  const phs=S.photos.filter(p=>p.workoutId===w.id);
  h+='<div class="grp"><div class="gh"><h2>Photos</h2></div><div class="thumbs">'+phs.map(p=>'<img class="thumb" src="'+esc(imgSrc(p))+'"'+imgAttr(p)+' data-act="openphoto" data-id="'+p.id+'" alt="">').join('')+'<button class="addthumb" data-act="addwphoto">+ Photo</button></div></div>';
  h+='<div class="grp"><div class="gh"><h2>Notes</h2></div><textarea class="in" data-s="w" data-f="notes" placeholder="How did it feel?">'+esc(w.notes)+'</textarea></div>';
  h+='<div style="margin-top:22px"><button class="btn pri block" data-act="back" style="padding:13px">Done</button></div>';
  return h;
}
function lastHtml(e,w){
  const l=lastSets(e.name,w.date,w.id);
  return l ? 'Last ('+fmtDate(l.date)+'): <b>'+l.sets.map(s=>esc(setStr(s,l.e,l.bw))).join(' · ')+'</b>' : '';
}
function tgtInputs(scope,e,i){
  return '<div class="tgt"><input class="in" inputmode="numeric" data-s="'+scope+'" data-t="num" data-f="exercises.'+i+'.targetSets" value="'+esc(e.targetSets??'')+'" placeholder="3" aria-label="Target sets"><span>sets ×</span><input class="in" inputmode="decimal" data-s="'+scope+'" data-t="num" data-f="exercises.'+i+'.targetReps" value="'+esc(e.targetReps??'')+'" placeholder="10" aria-label="Target '+unitLabel(e.unit)+'"><span>'+unitLabel(e.unit)+'</span></div>';
}
const loadTxt = (s,e,bw) => e.bw ? (bw!=null ? '= '+fmtN(bw+(num(s.kg)||0))+' kg' : 'BW'+(num(s.kg)?signed(num(s.kg)):'')) : '';
function exCard(e,i,label){
  const time=e.unit!=='reps'; const bw=wBW(S.draft);
  let h='<div class="ex'+(e.alt?' alt':'')+(isDone(e)?'':' skipped')+'" id="ex-'+i+'"><div class="ex-head"><span class="num">'+label+'</span><input class="ex-name" list="exnames" data-s="w" data-f="exercises.'+i+'.name" value="'+esc(e.name)+'" placeholder="Exercise name"><button class="iconbtn" data-act="exmenu" data-i="'+i+'" aria-label="Exercise options">'+dots+'</button></div>';
  h+='<div class="ex-meta">'+tgtInputs('w',e,i)+'<input class="in note-in" data-s="w" data-f="exercises.'+i+'.note" value="'+esc(e.note)+'" placeholder="Note (e.g. With bar)"></div>';
  if(e.bw) h+='<div class="bwline"><span class="badge">Body weight</span> &nbsp;Load = '+(bw!=null?fmtN(bw)+' kg':'BW')+' + kg below. Use <b>−</b> for support (e.g. −20).</div>';
  h+='<div class="last" id="last-'+i+'">'+lastHtml(e,S.draft)+'</div>';
  h+='<div class="sets"><div class="setrow hd'+(time?' time':'')+'"><span style="text-align:center">Set</span>'+(time?'':'<span style="text-align:center">'+(e.bw?'± kg':'kg')+'</span>')+'<span style="text-align:center">'+unitLabel(e.unit)+'</span><span>Note</span><span></span></div>';
  e.sets.forEach((s,j)=>{
    const kgIn='<input inputmode="'+(e.bw?'text':'decimal')+'" data-s="w" data-t="num" data-f="exercises.'+i+'.sets.'+j+'.kg" value="'+esc(s.kg??'')+'" placeholder="'+(e.bw?'±0':'kg')+'">';
    h+='<div class="setrow'+(time?' time':'')+'"><span class="sn">'+(j+1)+'</span>'+(time?'':(e.bw?'<div class="kgc">'+kgIn+'<span class="ld" id="ld-'+i+'-'+j+'">'+loadTxt(s,e,bw)+'</span></div>':kgIn))+'<input inputmode="decimal" data-s="w" data-t="num" data-f="exercises.'+i+'.sets.'+j+'.reps" value="'+esc(s.reps??'')+'" placeholder="'+esc(e.targetReps??unitLabel(e.unit))+'"><input class="note" data-s="w" data-f="exercises.'+i+'.sets.'+j+'.note" value="'+esc(s.note)+'" placeholder="WG, R/L…"><button class="iconbtn" data-act="delset" data-i="'+i+'" data-j="'+j+'" aria-label="Remove set"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>';
  });
  h+='</div><button class="btn sm addset" data-act="addset" data-i="'+i+'">+ Set</button></div>';
  return h;
}
function updateLoads(){ const w=S.draft; const bw=wBW(w); w.exercises.forEach((e,i)=>{ if(!e.bw) return; e.sets.forEach((s,j)=>{ const el=$('#ld-'+i+'-'+j); if(el) el.textContent=loadTxt(s,e,bw); }); }); }
function syncSets(ex){ const n=num(ex.targetSets)||0; if(!n||n>20) return; while(ex.sets.length<n){ const l=ex.sets[ex.sets.length-1]; ex.sets.push({kg:l?l.kg:null,reps:null,note:''}); } while(ex.sets.length>n){ const l=ex.sets[ex.sets.length-1]; if(num(l.reps)!=null||l.note) break; ex.sets.pop(); } }
let saveT=null;
function scheduleSave(){ clearTimeout(saveT); setSync('busy','Editing…'); saveT=setTimeout(saveDraft,700); }
function saveDraft(){ clearTimeout(saveT); if(S.draft) put('workouts',S.draft.id,Object.assign(S.draft,{updatedAt:Date.now()})); }
function rerenderWorkout(){ const y=window.scrollY; render(); window.scrollTo(0,y); }
function exOptions(e,i,p){
  return '<h3>'+esc(e.name||'Exercise')+'</h3>'+
   '<div class="field"><label>Load</label><div class="seg"><button class="'+(!e.bw?'on':'')+'" data-act="'+p+'load" data-i="'+i+'" data-v="0">Weight (kg)</button><button class="'+(e.bw?'on':'')+'" data-act="'+p+'load" data-i="'+i+'" data-v="1">Body weight ± kg</button></div><div class="help">Body weight: pull-ups, dips, push-ups. Load = your body weight + added kg, or minus the support (assisted machine / band).</div></div>'+
   '<div class="field" style="margin-top:12px"><label>Section</label><div class="seg">'+GROUPS.map(g=>'<button class="'+((e.group||'Main')===g?'on':'')+'" data-act="'+p+'group" data-i="'+i+'" data-g="'+g+'">'+g+'</button>').join('')+'</div></div>'+
   '<div class="field" style="margin-top:12px"><label>Count sets in</label><div class="seg">'+['reps','min','sec'].map(u=>'<button class="'+(e.unit===u?'on':'')+'" data-act="'+p+'unit" data-i="'+i+'" data-u="'+u+'">'+u+'</button>').join('')+'</div></div>'+
   '<div class="menu" style="margin-top:14px"><button class="btn" data-act="'+p+'alt" data-i="'+i+'">'+(e.alt?'Make it a main exercise':'Mark as “Or” alternative to the one above')+'</button><button class="btn" data-act="'+p+'move" data-i="'+i+'" data-d="-1">Move up</button><button class="btn" data-act="'+p+'move" data-i="'+i+'" data-d="1">Move down</button><button class="btn danger" data-act="'+p+'del" data-i="'+i+'">'+(p==='ex'?'Delete exercise':'Remove from routine')+'</button></div>';
}
function workoutText(w){
  const d=pd(w.date); const bw=wBW(w);
  let t='Week '+(w.week??0)+' '+DAYS[d.getDay()]+' '+d.getDate()+' '+MON[d.getMonth()]+' '+d.getFullYear()+'\n'+(w.title||'Workout')+(w.duration?' '+w.duration:'')+(bw?'\nBody weight '+fmtN(bw)+' kg':'')+'\n';
  const order=[...GROUPS, ...[...new Set(w.exercises.map(e=>e.group))].filter(g=>!GROUPS.includes(g))];
  order.forEach(g=>{ const list=w.exercises.filter(e=>(e.group||'Main')===g); if(!list.length) return;
    t+= g!=='Main' ? '\n'+(GLABEL[g]||g)+'\n' : '\n';
    let n=0; list.forEach(e=>{ if(!e.alt) n++; const time=e.unit!=='reps';
      let wts=''; if(!time){ const ks=e.sets.map(s=>num(s.kg)||0);
        wts = e.bw ? ' (BW'+(bw?' '+fmtN(bw):'')+(ks.some(k=>k)?': '+ks.map(k=>k?signed(k):'±0').join(', '):'')+' Kg)' : ' ('+(ks.length?ks.map(fmtN).join(', '):'0')+' Kg)'; }
      t+=(e.alt?'Or ':n+' ')+e.name+' '+targetStr(e)+wts+(e.note?' '+e.note:'')+'\n';
      t+='Actual set done ('+(isDone(e)||e.sets.some(s=>s.note)? e.sets.map(s=>(s.reps??0)+(time?' '+e.unit:'')+(s.note?' '+s.note:'')).join(', ') : '0')+')\n';
    });
  });
  if(w.notes) t+='\n'+w.notes+'\n';
  return t;
}
async function copyText(txt){
  try{ await navigator.clipboard.writeText(txt); toast('Copied'); }
  catch(e){ sheet('<h3>Copy</h3><textarea class="in" style="min-height:320px;font-size:13px" readonly>'+esc(txt)+'</textarea><p class="muted small">Select all and copy.</p>'); }
}

/* ---- Progress ---- */
function exerciseIndex(){
  const m=new Map();
  S.workouts.forEach(w=>(w.exercises||[]).forEach(e=>{ if(!isDone(e)) return; const k=key(e.name); if(!m.has(k)) m.set(k,{name:e.name.trim(),n:0,unit:e.unit}); m.get(k).n++; }));
  return [...m.entries()].sort((a,b)=>b[1].n-a[1].n||a[1].name.localeCompare(b[1].name));
}
function exSeries(k){
  const rows=[];
  [...S.workouts].sort((a,b)=>(a.date||'').localeCompare(b.date||'')).forEach(w=>{ const bw=wBW(w); (w.exercises||[]).forEach(e=>{
    if(key(e.name)!==k || !isDone(e)) return; const ds=doneSets(e);
    const top=Math.max(...ds.map(s=>setLoad(s,e,bw)));
    const orm=Math.max(...ds.map(s=>{const l=setLoad(s,e,bw),r=num(s.reps)||0; return l>0? l*(1+r/30):0;}));
    rows.push({w, e, bw, date:w.date, week:+w.week||0, top, vol:exVolume(e,bw), reps:ds.reduce((a,s)=>a+(num(s.reps)||0),0), orm, sets:ds});
  }); });
  return rows;
}
const METRICS={top:'Top load (kg)',vol:'Volume (kg × reps)',reps:'Total reps',orm:'Est. 1-rep max (kg)'};
function weekRows(){
  const m=new Map(); S.workouts.forEach(w=>{ const k=+w.week||0; if(!m.has(k)) m.set(k,{week:k,n:0,sets:0,vol:0}); const r=m.get(k); r.n++; r.sets+=wSets(w); r.vol+=wVolume(w); });
  return [...m.values()].sort((a,b)=>a.week-b.week);
}
function vProgress(){
  if(!S.workouts.length) return '<div class="empty">Log a workout and your progress shows up here.</div>';
  const wr=weekRows(); const cur=wr[wr.length-1], prev=wr[wr.length-2];
  const d = prev && prev.vol ? Math.round((cur.vol-prev.vol)/prev.vol*100) : null;
  let h='<div class="sec-title"><h2>Week '+cur.week+'</h2><span class="muted small">latest</span></div>';
  h+='<div class="tiles"><div class="tile"><div class="v">'+cur.n+'</div><div class="l">sessions</div></div><div class="tile"><div class="v">'+cur.sets+'</div><div class="l">working sets</div></div><div class="tile"><div class="v">'+fmtN(cur.vol)+'</div><div class="l">kg volume'+(d!=null?' <span class="delta '+(d>=0?'up':'down')+'">'+(d>=0?'▲':'▼')+Math.abs(d)+'%</span>':'')+'</div></div></div>';
  const idx=exerciseIndex();
  if(!S.progEx || !idx.some(([k])=>k===S.progEx)) S.progEx = (idx.find(([k])=>k==='bench press')||idx[0]||[null])[0];
  if(S.progEx){
    const info=idx.find(([k])=>k===S.progEx)[1]; const rows=exSeries(S.progEx);
    const noLoad = rows.every(r=>r.top===0);
    if(!S.progMetric || (noLoad && S.progMetric!=='reps')) S.progMetric = noLoad?'reps':'top';
    const mets = noLoad?['reps']:['top','vol','reps','orm'];
    h+='<div class="sec-title"><h2>Exercise</h2></div><div class="card"><select class="in" id="exsel">'+idx.map(([k,v])=>'<option value="'+esc(k)+'"'+(k===S.progEx?' selected':'')+'>'+esc(v.name)+' ('+v.n+')</option>').join('')+'</select>';
    if(rows.some(r=>r.e.bw)) h+='<div class="help">Body-weight exercise: load = body weight that day ± added/support kg.'+(rows.some(r=>r.e.bw&&r.bw==null)?' Some sessions have no body weight yet, so they show 0.':'')+'</div>';
    h+='<div class="seg" style="margin-top:10px">'+mets.map(m=>'<button class="'+(S.progMetric===m?'on':'')+'" data-act="metric" data-m="'+m+'">'+({top:'Top kg',vol:'Volume',reps:info.unit!=='reps'?'Total '+info.unit:'Reps',orm:'Est. 1RM'})[m]+'</button>').join('')+'</div>';
    h+='<div class="chartbox"><canvas id="c-ex" aria-label="'+esc(info.name)+' progress chart" role="img"></canvas></div>';
    h+='<table class="t"><thead><tr><th>Date</th><th>Wk</th><th>Sets done</th><th class="n">'+(S.progMetric==='vol'?'Vol':S.progMetric==='reps'?'Reps':S.progMetric==='orm'?'1RM':'Top')+'</th></tr></thead><tbody>'+
      [...rows].reverse().map(r=>'<tr data-act="openw" data-id="'+r.w.id+'" style="cursor:pointer"><td>'+fmtDate(r.date)+'</td><td>'+r.week+'</td><td>'+r.sets.map(s=>esc(setStr(s,r.e,r.bw))).join(' · ')+'</td><td class="n">'+fmtN(r[S.progMetric])+'</td></tr>').join('')+'</tbody></table></div>';
  }
  h+='<div class="sec-title"><h2>Week by week</h2></div><div class="card"><div class="muted small">Total volume per week (load × reps, all exercises)</div><div class="chartbox" style="height:200px"><canvas id="c-week" role="img" aria-label="Weekly volume chart"></canvas></div>';
  h+='<table class="t"><thead><tr><th>Week</th><th class="n">Sessions</th><th class="n">Sets</th><th class="n">Volume</th><th class="n">Δ</th></tr></thead><tbody>'+[...wr].reverse().map((r,i,a)=>{ const p=a[i+1]; const dd=p&&p.vol?Math.round((r.vol-p.vol)/p.vol*100):null; return '<tr><td>Week '+r.week+'</td><td class="n">'+r.n+'</td><td class="n">'+r.sets+'</td><td class="n">'+fmtN(r.vol)+'</td><td class="n">'+(dd==null?'–':'<span class="delta '+(dd>=0?'up':'down')+'">'+(dd>=0?'+':'')+dd+'%</span>')+'</td></tr>'; }).join('')+'</tbody></table></div>';
  return h;
}
function baseOpts(yTitle){
  return { responsive:true, maintainAspectRatio:false, animation:false,
    interaction:{mode:'index',intersect:false},
    plugins:{legend:{display:false}, tooltip:{backgroundColor:'#F2F3F5',titleColor:'#0E0F11',bodyColor:'#0E0F11',padding:10,displayColors:false,titleFont:{weight:'600'}}},
    scales:{ x:{grid:{display:false},ticks:{color:'#9AA1AA',maxRotation:0,autoSkip:true}, border:{color:'#2A2E33'}},
             y:{beginAtZero:false, grace:'10%', grid:{color:'#22262B'}, ticks:{color:'#9AA1AA'}, border:{display:false}, title:{display:!!yTitle,text:yTitle,color:'#6B727B'}} } };
}
const lineDs = data => ({data,borderColor:'#B8E62E',backgroundColor:'#B8E62E',borderWidth:2,pointRadius:4,pointHoverRadius:6,pointBorderColor:'#17191C',pointBorderWidth:2,tension:0});
function drawCharts(){
  if(typeof Chart==='undefined') return;
  Chart.defaults.font.family='Barlow, system-ui, sans-serif';
  const ce=$('#c-ex');
  if(ce && S.progEx){
    const rows=exSeries(S.progEx); const m=S.progMetric;
    const o=baseOpts(METRICS[m]); o.plugins.tooltip.callbacks={ title:it=>{const r=rows[it[0].dataIndex]; return fmtDate(r.date)+' · Week '+r.week;}, label:it=>{const r=rows[it.dataIndex]; return [METRICS[m]+': '+fmtN(it.parsed.y), r.sets.map(s=>setStr(s,r.e,r.bw)).join(' · ')];} };
    charts.push(new Chart(ce,{type:'line',data:{labels:rows.map(r=>fmtDate(r.date).slice(4)),datasets:[lineDs(rows.map(r=>Math.round(r[m]*10)/10))]},options:o}));
  }
  const cw=$('#c-week');
  if(cw){ const wr=weekRows(); const o=baseOpts(); o.scales.y.beginAtZero=true; o.plugins.tooltip.callbacks={title:it=>'Week '+wr[it[0].dataIndex].week, label:it=>{const r=wr[it.dataIndex]; return [fmtN(r.vol)+' kg volume', r.n+' sessions · '+r.sets+' sets'];}};
    charts.push(new Chart(cw,{type:'bar',data:{labels:wr.map(r=>'Wk '+r.week),datasets:[{data:wr.map(r=>Math.round(r.vol)),backgroundColor:'#B8E62E',borderRadius:{topLeft:4,topRight:4},borderSkipped:'bottom',maxBarThickness:36}]},options:o})); }
  const cb=$('#c-bw');
  if(cb){ const rows=bwPeriods(S.bwMode); const o=baseOpts('kg'); o.plugins.tooltip.callbacks={title:it=>rows[it[0].dataIndex].label, label:it=>{const r=rows[it.dataIndex]; return [fmtN(r.avg)+' kg'+(r.n>1?' (avg of '+r.n+')':''), r.range];}};
    charts.push(new Chart(cb,{type:'line',data:{labels:rows.map(r=>r.short),datasets:[lineDs(rows.map(r=>Math.round(r.avg*10)/10))]},options:o})); }
}

/* ---- Body: weight + photos ---- */
function bwPeriods(mode){
  const m=new Map();
  bwSorted().forEach(b=>{ let k,label,short;
    if(mode==='monthly'){ const d=pd(b.date); k=d.getFullYear()*100+d.getMonth(); label=MONL[d.getMonth()]+' '+d.getFullYear(); short=MON[d.getMonth()]+(d.getMonth()===0?' '+String(d.getFullYear()).slice(2):''); }
    else { k=programWeek(b.date); label='Week '+k; short='Wk '+k; }
    if(!m.has(k)) m.set(k,{k,label,short,vals:[],dates:[]}); const r=m.get(k); r.vals.push(num(b.kg)); r.dates.push(b.date); });
  return [...m.values()].sort((a,b)=>a.k-b.k).map(r=>({...r, n:r.vals.length, avg:r.vals.reduce((a,v)=>a+v,0)/r.vals.length, range: r.dates.length>1? fmtDate(r.dates[0])+' – '+fmtDate(r.dates[r.dates.length-1]) : fmtDate(r.dates[0])}));
}
function vBody(){
  const all=bwSorted(); const last=all[all.length-1]; const first=all[0];
  let h='<div class="sec-title"><h2>Body weight</h2></div>';
  h+='<div class="card">';
  if(last){ const ch=all.length>1? num(last.kg)-num(first.kg) : null;
    h+='<div class="row" style="align-items:flex-end;margin-bottom:12px"><div><div class="bighero">'+fmtN(last.kg)+' <span style="font-size:20px" class="muted">kg</span></div><div class="muted small">'+fmtDate(last.date)+' · Week '+programWeek(last.date)+'</div></div><span class="sp"></span>'+(ch!=null?'<div style="text-align:right"><div class="cond" style="font-size:22px">'+(ch>0?'+':ch<0?'−':'±')+fmtN(Math.abs(ch))+' kg</div><div class="muted small">since '+fmtDate(first.date)+'</div></div>':'')+'</div>'; }
  h+='<div class="bwform"><div class="field"><label>Date</label><input class="in" type="date" id="bwdate" value="'+today()+'"></div><div class="field"><label>Weight (kg)</label><input class="in" id="bwkg" inputmode="decimal" placeholder="'+(last?fmtN(last.kg):'80')+'"></div><button class="btn pri" data-act="bwsave" style="padding:10px 16px">Save</button></div><div class="help">One entry per day; saving the same date again replaces it. Weigh in at least once a week.</div></div>';
  if(all.length){
    const rows=bwPeriods(S.bwMode);
    h+='<div class="card" style="margin-top:10px"><div class="seg"><button class="'+(S.bwMode==='weekly'?'on':'')+'" data-act="bwmode" data-m="weekly">Weekly</button><button class="'+(S.bwMode==='monthly'?'on':'')+'" data-act="bwmode" data-m="monthly">Monthly</button></div>';
    h+='<div class="chartbox" style="height:200px"><canvas id="c-bw" role="img" aria-label="Body weight '+S.bwMode+' chart"></canvas></div>';
    h+='<table class="t"><thead><tr><th>'+(S.bwMode==='weekly'?'Week':'Month')+'</th><th class="n">Avg kg</th><th class="n">Change</th><th class="n">Entries</th></tr></thead><tbody>'+[...rows].reverse().map((r,i,a)=>{ const p=a[i+1]; const dd=p? r.avg-p.avg : null; return '<tr><td>'+r.label+'</td><td class="n">'+fmtN(r.avg)+'</td><td class="n">'+(dd==null?'–':'<span>'+(dd>0?'+':dd<0?'−':'±')+fmtN(Math.abs(dd))+'</span>')+'</td><td class="n">'+r.n+'</td></tr>'; }).join('')+'</tbody></table>';
    h+='<details style="margin-top:10px"><summary class="muted small" style="cursor:pointer">All entries ('+all.length+')</summary><table class="t">'+[...all].reverse().map(b=>'<tr><td>'+fmtDate(b.date)+' '+pd(b.date).getFullYear()+'</td><td class="n">'+fmtN(b.kg)+' kg</td><td class="n" style="width:36px"><button class="iconbtn" data-act="bwdel" data-id="'+b.id+'" aria-label="Delete entry"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></td></tr>').join('')+'</table></details></div>';
  }
  h+='<div class="sec-title"><h2>Progress photos</h2></div>';
  h+='<div class="row"><button class="btn pri" data-act="addphoto" style="flex:1;padding:12px">+ Add photo</button>'+(S.photos.length>1?'<button class="btn" data-act="cmptoggle" style="padding:12px">'+(S.comparing?'Cancel':'Compare')+'</button>':'')+'</div>';
  if(S.comparing) h+='<p class="muted small">Pick two photos to compare side by side.</p>';
  h+='<div class="chips" style="margin-top:12px">'+[['all','All'],['weekly','Weekly'],['monthly','Monthly'],['workout','Workout'],['other','Other']].map(([k,l])=>'<button class="chip'+(S.photoFilter===k?' on':'')+'" data-act="pfilter" data-k="'+k+'">'+l+'</button>').join('')+'</div>';
  const list=S.photos.filter(p=>S.photoFilter==='all'||p.kind===S.photoFilter).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||(b.createdAt||0)-(a.createdAt||0));
  if(!list.length) return h+'<div class="empty">No photos yet. Add your weekly and monthly body pics to see the change over time.</div>';
  const months=new Map(); list.forEach(p=>{ const d=pd(p.date); const k=d.getFullYear()+'-'+pad(d.getMonth()+1); if(!months.has(k)) months.set(k,[]); months.get(k).push(p); });
  months.forEach((ps,k)=>{ const [y,m]=k.split('-');
    h+='<div class="weekhead"><h2>'+MONL[+m-1]+' '+y+'</h2><span class="muted small">'+ps.length+'</span></div><div class="gallery">';
    ps.forEach(p=>{ const si=S.cmpSel.indexOf(p.id); const bw=bwOn(p.date);
      h+='<div class="ph'+(si>=0?' sel':'')+'" data-act="'+(S.comparing?'cmppick':'openphoto')+'" data-id="'+p.id+'"><img loading="lazy" src="'+esc(imgSrc(p))+'"'+imgAttr(p)+' alt="Progress photo '+esc(p.date)+'"><span class="kind">'+esc(p.kind||'other')+'</span>'+(si>=0?'<span class="selno">'+(si+1)+'</span>':'')+'<div class="cap">'+fmtDate(p.date)+(bw?' · '+fmtN(bw)+' kg':'')+'</div></div>'; });
    h+='</div>';
  });
  return h;
}
function saveBW(){
  const date=($('#bwdate')||{}).value||today(); const kg=num(($('#bwkg')||{}).value);
  if(!kg||kg<20||kg>400){ toast('Enter your weight in kg'); return; }
  put('bodyweight','bw-'+date,{date,kg,createdAt:Date.now()}); toast('Saved '+fmtN(kg)+' kg'); render();
}
function photoForm(p,isNew){
  S.pdraft=p;
  sheet('<h3>'+(isNew?'New photo':'Photo')+'</h3><div class="big"><img src="'+esc(imgSrc(p))+'"'+imgAttr(p)+' alt=""></div>'+
   '<div class="field" style="margin-top:12px"><label>Date</label><input class="in" type="date" data-s="p" data-f="date" value="'+esc(p.date)+'"></div>'+
   '<div class="field" style="margin-top:10px"><label>Type</label><div class="seg">'+[['weekly','Weekly'],['monthly','Monthly'],['workout','Workout'],['other','Other']].map(([k,l])=>'<button class="'+(p.kind===k?'on':'')+'" data-act="pkind" data-k="'+k+'">'+l+'</button>').join('')+'</div></div>'+
   '<div class="field" style="margin-top:10px"><label>Note</label><input class="in" data-s="p" data-f="note" value="'+esc(p.note||'')+'" placeholder="optional"></div>'+
   '<div class="row" style="margin-top:16px">'+(isNew?'':'<button class="btn danger" data-act="pdel">Delete</button>')+'<span class="sp"></span><button class="btn pri" data-act="psave">'+(isNew?'Save photo':'Save')+'</button></div>');
}
async function addPhoto(workoutId){
  if(!navigator.onLine){ toast('Photos need a connection to upload'); return; }
  const f=await pickFile(); if(!f) return;
  const preview=URL.createObjectURL(f);
  const p={id:uid('p'), date: workoutId? S.draft.date : today(), kind: workoutId?'workout':(pd(today()).getDate()<=7?'monthly':'weekly'), note:'', workoutId:workoutId||null, createdAt:Date.now(), _file:f, _preview:preview};
  photoForm(p,true);
}
function compareView(){
  const [a,b]=S.cmpSel.map(id=>S.photos.find(p=>p.id===id)).sort((x,y)=>x.date.localeCompare(y.date));
  const days=Math.round((pd(b.date)-pd(a.date))/864e5);
  const wa=bwOn(a.date), wb=bwOn(b.date); const dw = wa!=null&&wb!=null ? wb-wa : null;
  sheet('<h3>Compare</h3><div class="cmp"><div><img src="'+esc(imgSrc(a))+'"'+imgAttr(a)+' alt=""><div class="small" style="margin-top:6px"><b>'+fmtDate(a.date)+'</b>'+(wa?' · '+fmtN(wa)+' kg':'')+'</div></div><div><img src="'+esc(imgSrc(b))+'"'+imgAttr(b)+' alt=""><div class="small" style="margin-top:6px"><b>'+fmtDate(b.date)+'</b>'+(wb?' · '+fmtN(wb)+' kg':'')+'</div></div></div><p class="muted" style="margin-top:12px">'+days+' days apart'+(dw!=null?' · '+(dw>=0?'+':'−')+fmtN(Math.abs(dw))+' kg':'')+'</p>');
}

/* ---- Routines ---- */
function vRoutines(){
  const ts=[...S.templates].sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  let h='<div class="sec-title"><h2>Routines</h2><span class="sp"></span><button class="btn sm" data-act="newt">+ New</button></div>';
  if(!ts.length) h+='<div class="empty">No routines yet.</div>';
  ts.forEach(t=>{ h+='<div class="card" style="margin-bottom:8px"><div class="row"><div style="flex:1;min-width:0"><h3 style="font-size:20px">'+esc(t.name)+'</h3><div class="muted small" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+(t.exercises||[]).filter(e=>!e.alt).map(e=>esc(e.name)).join(' · ')+'</div></div><button class="btn sm" data-act="editt" data-id="'+t.id+'">Edit</button><button class="btn sm pri" data-act="startt" data-id="'+t.id+'">Start</button></div></div>'; });
  const u=store.currentUser(); const st=store.getStatus();
  h+='<div class="sec-title"><h2>Account & data</h2></div><div class="card"><p class="muted small" style="margin-top:0">Signed in as <b style="color:var(--text)">'+esc(u&&u.email)+'</b>. Data lives in your Supabase project and works offline; changes upload when you\'re back online.'+(st.pending?' <span style="color:#f3c98a">'+st.pending+' change'+(st.pending>1?'s':'')+' waiting to upload.</span>':'')+'</p><div class="row wrap2"><button class="btn sm" data-act="backup">Download backup</button><button class="btn sm" data-act="restore">Restore from backup</button><button class="btn sm" data-act="syncnow">Sync now</button><span class="sp"></span><button class="btn sm danger" data-act="signout">Sign out</button></div></div>';
  return h;
}
function openTemplate(t,isNew){ S.tdraft=clone(t); S.route={name:'template',id:t.id}; render(); window.scrollTo(0,0); if(isNew) put('templates',S.tdraft.id,S.tdraft); }
function vTemplate(){
  const t=S.tdraft;
  let h='<div class="backbar"><button class="btn sm ghost" data-act="tback">‹ Routines</button><span class="sp"></span><button class="btn sm danger" data-act="tdel">Delete</button></div>';
  h+='<div class="card"><div class="field"><label>Routine name</label><input class="in" data-s="t" data-f="name" value="'+esc(t.name)+'" style="font-size:18px;font-weight:600"></div></div>';
  GROUPS.forEach(g=>{
    const idx=t.exercises.map((e,i)=>({e,i})).filter(x=>(x.e.group||'Main')===g);
    h+='<div class="grp"><div class="gh"><h2>'+GLABEL[g]+'</h2></div>';
    let n=0;
    idx.forEach(({e,i})=>{ if(!e.alt) n++;
      h+='<div class="tex'+(e.alt?' alt':'')+'"><div class="ex-head"><span class="num">'+(e.alt?'OR':n)+'</span><input class="ex-name" list="exnames" data-s="t" data-f="exercises.'+i+'.name" value="'+esc(e.name)+'" placeholder="Exercise name"><button class="iconbtn" data-act="texmenu" data-i="'+i+'" aria-label="Options">'+dots+'</button></div><div class="ex-meta">'+tgtInputs('t',e,i)+'<input class="in note-in" data-s="t" data-f="exercises.'+i+'.note" value="'+esc(e.note)+'" placeholder="Note"></div>'+(e.bw?'<div class="bwline"><span class="badge">Body weight ± kg</span></div>':'')+'</div>'; });
    h+='<button class="btn sm ghost" data-act="taddex" data-g="'+g+'">+ Add exercise</button></div>';
  });
  h+='<div style="margin-top:22px" class="row"><button class="btn block" data-act="tback" style="padding:13px">Done</button><button class="btn pri block" data-act="startt" data-id="'+t.id+'" style="padding:13px">Start this workout</button></div>';
  return h;
}
let tsaveT=null;
function scheduleTSave(){ clearTimeout(tsaveT); setSync('busy','Editing…'); tsaveT=setTimeout(()=>{ if(S.tdraft) put('templates',S.tdraft.id,S.tdraft); },700); }

/* ============ sheet + confirm ============ */
function sheet(html){ $('#layer').innerHTML='<div class="scrim" data-act="scrim"><div class="sheet" role="dialog">'+html+'</div></div>'; hydrateImages($('#layer')); }
function closeSheet(){ $('#layer').innerHTML=''; }
let confirmCb=null;
function confirmBox(msg,ok,cb){ confirmCb=cb; sheet('<h3>Are you sure?</h3><p class="muted">'+esc(msg)+'</p><div class="row" style="margin-top:16px"><span class="sp"></span><button class="btn" data-act="closesheet">Cancel</button><button class="btn danger" data-act="confirmok">'+esc(ok)+'</button></div>'); }
function moveEx(arr,i,d){ const j=i+d; if(j<0||j>=arr.length) return; [arr[i],arr[j]]=[arr[j],arr[i]]; }
function newEx(g){ const n=g==='Finishers'?2:3; return {name:'',group:g,alt:false,bw:false,targetSets:n,targetReps:10,unit:'reps',note:''}; }

/* ============ events ============ */
document.addEventListener('input', ev=>{
  const el=ev.target; const f=el.dataset.f; if(!f) return;
  let v=el.value; if(el.dataset.t==='num') v=num(v);
  if(el.dataset.s==='w' && S.draft){
    setPath(S.draft,f,v); scheduleSave();
    if(f==='date'){ $('#dayname').textContent=DAYS[pd(v).getDay()]; }
    if(f==='bodyWeight'||/\.kg$/.test(f)) updateLoads();
    const m=f.match(/^exercises\.(\d+)\.sets/); if(m){ const card=$('#ex-'+m[1]); if(card) card.classList.toggle('skipped', !isDone(S.draft.exercises[+m[1]])); }
  } else if(el.dataset.s==='t' && S.tdraft){ setPath(S.tdraft,f,v); scheduleTSave(); }
  else if(el.dataset.s==='p' && S.pdraft){ setPath(S.pdraft,f,v); }
});
document.addEventListener('change', ev=>{
  const el=ev.target;
  if(el.id==='exsel'){ S.progEx=el.value; S.progMetric=null; render(); return; }
  const f=el.dataset.f||'';
  const m=f.match(/^exercises\.(\d+)\.name$/);
  if(m && el.dataset.s==='w'){ const l=$('#last-'+m[1]); if(l) l.innerHTML=lastHtml(S.draft.exercises[+m[1]],S.draft); refreshDatalist(); }
  const ts=f.match(/^exercises\.(\d+)\.targetSets$/);
  if(ts && el.dataset.s==='w'){ syncSets(S.draft.exercises[+ts[1]]); scheduleSave(); rerenderWorkout(); }
  if(f==='bodyWeight' && el.dataset.s==='w'){ rerenderWorkout(); }
});
document.addEventListener('keydown', ev=>{ if(ev.key==='Enter' && ev.target.id==='bwkg'){ ev.preventDefault(); saveBW(); } });
function rerenderT(){ const y=scrollY; render(); scrollTo(0,y); }
document.addEventListener('click', async ev=>{
  const el=ev.target.closest('[data-act]'); if(!el) return;
  if(el.tagName==='A') ev.preventDefault();
  const a=el.dataset.act, i=+el.dataset.i, w=S.draft, t=S.tdraft;
  if(a==='scrim'){ if(ev.target===el) closeSheet(); return; }
  switch(a){
    case 'tab': if(S.route.name==='workout') saveDraft(); if(S.route.name==='template' && t){ clearTimeout(tsaveT); put('templates',t.id,t); S.tdraft=null; } S.route={name:el.dataset.tab}; S.comparing=false; S.cmpSel=[]; render(); window.scrollTo(0,0); break;
    case 'closesheet': closeSheet(); break;
    case 'confirmok': closeSheet(); if(confirmCb) confirmCb(); confirmCb=null; break;
    case 'startmenu': startMenu(); break;
    case 'startblank': newWorkout(null); break;
    case 'startt': { if(S.route.name==='template'){ put('templates',t.id,t); } const tp=S.templates.find(x=>x.id===el.dataset.id); if(tp) newWorkout(tp); break; }
    case 'openw': { const ww=S.workouts.find(x=>x.id===el.dataset.id); if(ww) openWorkout(ww,false); break; }
    case 'back': saveDraft(); S.draft=null; S.route={name:'log'}; render(); window.scrollTo(0,0); break;
    case 'addset': { const ex=w.exercises[i]; const last=ex.sets[ex.sets.length-1]; ex.sets.push({kg:last?last.kg:null,reps:null,note:''}); scheduleSave(); rerenderWorkout(); break; }
    case 'delset': w.exercises[i].sets.splice(+el.dataset.j,1); scheduleSave(); rerenderWorkout(); break;
    case 'addex': { const g=el.dataset.g; const e=newEx(g); e.sets=blankSets(e.targetSets,null); w.exercises.push(e); scheduleSave(); rerenderWorkout(); const inp=document.querySelector('[data-f="exercises.'+(w.exercises.length-1)+'.name"]'); if(inp){ inp.focus(); inp.scrollIntoView({block:'center'}); } break; }
    case 'exmenu': sheet(exOptions(w.exercises[i],i,'ex')); break;
    case 'exload': w.exercises[i].bw=el.dataset.v==='1'; closeSheet(); scheduleSave(); rerenderWorkout(); break;
    case 'exgroup': w.exercises[i].group=el.dataset.g; closeSheet(); scheduleSave(); rerenderWorkout(); break;
    case 'exunit': w.exercises[i].unit=el.dataset.u; closeSheet(); scheduleSave(); rerenderWorkout(); break;
    case 'exalt': w.exercises[i].alt=!w.exercises[i].alt; closeSheet(); scheduleSave(); rerenderWorkout(); break;
    case 'exmove': moveEx(w.exercises,i,+el.dataset.d); closeSheet(); scheduleSave(); rerenderWorkout(); break;
    case 'exdel': w.exercises.splice(i,1); closeSheet(); scheduleSave(); rerenderWorkout(); break;
    case 'wmenu': sheet('<h3>Workout</h3><div class="menu"><button class="btn" data-act="saveastpl">Save as routine</button><button class="btn" data-act="dupw">Repeat this workout today</button><button class="btn danger" data-act="delw">Delete workout</button></div>'); break;
    case 'saveastpl': { const nt={id:uid('t'),name:w.title||'Routine',exercises:w.exercises.map(e=>({name:e.name,group:e.group,alt:e.alt,bw:e.bw,targetSets:e.targetSets,targetReps:e.targetReps,unit:e.unit,note:e.note}))}; put('templates',nt.id,nt); closeSheet(); toast('Saved as routine'); break; }
    case 'dupw': { saveDraft(); const src=clone(w); closeSheet(); newWorkout({id:src.templateId,name:src.title,exercises:src.exercises}); break; }
    case 'delw': confirmBox('This deletes the workout for good.','Delete', ()=>{ clearTimeout(saveT); del('workouts',w.id); S.draft=null; S.route={name:'log'}; render(); }); break;
    case 'copytext': copyText(workoutText(w)); break;
    case 'metric': S.progMetric=el.dataset.m; render(); break;
    case 'bwsave': saveBW(); break;
    case 'bwmode': S.bwMode=el.dataset.m; render(); break;
    case 'bwdel': { const id=el.dataset.id; confirmBox('Delete this weigh-in?','Delete', ()=>{ del('bodyweight',id); render(); }); break; }
    case 'addphoto': addPhoto(null); break;
    case 'addwphoto': addPhoto(w.id); break;
    case 'pfilter': S.photoFilter=el.dataset.k; render(); break;
    case 'pkind': S.pdraft.kind=el.dataset.k; el.parentNode.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b===el)); break;
    case 'openphoto': { const p=S.photos.find(x=>x.id===el.dataset.id); if(p) photoForm(clone(p),false); break; }
    case 'psave': { const p=S.pdraft; if(!p) break;
      if(p._file){ el.disabled=true; el.innerHTML='<span class="spin"></span> Uploading'; try{ Object.assign(p, await storeImage(p._file,p.id)); }catch(e){ el.disabled=false; el.textContent='Save photo'; toast(e&&e.message==='offline'?'You\'re offline — try again with a connection':'Upload failed: '+((e&&e.message)||'error')); break; } URL.revokeObjectURL(p._preview); delete p._file; delete p._preview; }
      put('photos',p.id,p); S.pdraft=null; closeSheet(); if(S.route.name==='workout') rerenderWorkout(); else render(); break; }
    case 'pdel': { const p=S.pdraft; confirmBox('Delete this photo for good?','Delete', async ()=>{ await del('photos',p.id); if(p.path) store.deletePhoto(p.path); if(S.route.name==='workout') rerenderWorkout(); else render(); }); break; }
    case 'cmptoggle': S.comparing=!S.comparing; S.cmpSel=[]; render(); break;
    case 'cmppick': { const id=el.dataset.id; const k=S.cmpSel.indexOf(id); if(k>=0) S.cmpSel.splice(k,1); else { S.cmpSel.push(id); if(S.cmpSel.length>2) S.cmpSel.shift(); } render(); if(S.cmpSel.length===2) compareView(); break; }
    case 'newt': openTemplate({id:uid('t'),name:'New routine',exercises:[]},true); break;
    case 'editt': { const tp=S.templates.find(x=>x.id===el.dataset.id); if(tp) openTemplate(tp,false); break; }
    case 'tback': clearTimeout(tsaveT); put('templates',t.id,t); S.tdraft=null; S.route={name:'routines'}; render(); break;
    case 'tdel': confirmBox('Delete the routine “'+t.name+'”? Logged workouts stay.','Delete', ()=>{ clearTimeout(tsaveT); del('templates',t.id); S.tdraft=null; S.route={name:'routines'}; render(); }); break;
    case 'taddex': t.exercises.push(newEx(el.dataset.g)); scheduleTSave(); rerenderT(); break;
    case 'texmenu': sheet(exOptions(t.exercises[i],i,'tex')); break;
    case 'texload': t.exercises[i].bw=el.dataset.v==='1'; closeSheet(); scheduleTSave(); rerenderT(); break;
    case 'texgroup': t.exercises[i].group=el.dataset.g; closeSheet(); scheduleTSave(); rerenderT(); break;
    case 'texunit': t.exercises[i].unit=el.dataset.u; closeSheet(); scheduleTSave(); rerenderT(); break;
    case 'texalt': t.exercises[i].alt=!t.exercises[i].alt; closeSheet(); scheduleTSave(); rerenderT(); break;
    case 'texmove': moveEx(t.exercises,i,+el.dataset.d); closeSheet(); scheduleTSave(); rerenderT(); break;
    case 'texdel': t.exercises.splice(i,1); closeSheet(); scheduleTSave(); rerenderT(); break;
    case 'backup': { const txt=JSON.stringify({app:'gym-log',version:3,exportedAt:new Date().toISOString(),workouts:S.workouts,templates:S.templates,bodyweight:S.bodyweight,photos:S.photos},null,1);
      const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([txt],{type:'application/json'})); a.download='gym-log-backup-'+today()+'.json'; document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(a.href); a.remove();},1000); toast('Backup downloaded'); break; }
    case 'syncnow': await store.flush(); await store.pull(); toast(store.getStatus().pending?'Some changes are still waiting':'Up to date'); render(); break;
    case 'signout': confirmBox('Sign out on this device?','Sign out', async ()=>{ try{ await store.signOut(); }catch(e){ toast('Can\'t sign out yet — some changes haven\'t uploaded. Get online first.'); } }); break;
    case 'authmode': S.authMode=el.dataset.m; render(); break;
    case 'authgo': doAuth(); break;
    case 'restorefile': { const f=await pickFile('.json,application/json'); if(f){ $('#restoretxt').value=await f.text(); } break; }
    case 'restore': sheet('<h3>Restore</h3><p class="muted small">Choose a backup file (or paste its contents). Entries with the same id are overwritten; nothing is deleted.</p><button class="btn sm" data-act="restorefile" style="margin-bottom:8px">Choose file…</button><textarea class="in" id="restoretxt" style="min-height:180px;font-size:12px" placeholder="…or paste backup JSON here"></textarea><div class="row" style="margin-top:12px"><span class="sp"></span><button class="btn pri" data-act="dorestore">Restore</button></div>'); break;
    case 'dorestore': { try{ const d=JSON.parse($('#restoretxt').value); let n=0; for(const c of COLLS){ for(const r of (d[c]||[])){ if(r&&r.id){ if(c==='photos'&&!r.path) continue; await put(c,r.id,normalize(c,r)); n++; } } } closeSheet(); toast('Restored '+n+' entries'); render(); }catch(e){ toast('That isn\'t a valid backup'); } break; }
  }
});
window.addEventListener('pagehide', ()=>{ if(S.draft) saveDraft(); });

/* ============ auth + boot ============ */
function vNoConfig(){
  return '<div class="card" style="margin-top:20px"><h2 style="font-size:22px;text-transform:uppercase">Almost there</h2><p class="muted">This copy of Gym Log isn\'t connected to a Supabase project yet. Add your Project URL and anon key to <code>js/config.js</code> (or as GitHub repository secrets for the deploy) — see the README.</p></div>';
}
function vAuth(){
  const up=S.authMode==='signup';
  return '<div class="card" style="margin-top:28px;max-width:420px;margin-left:auto;margin-right:auto"><h2 style="font-size:26px;text-transform:uppercase;margin-bottom:4px">'+(up?'Create account':'Sign in')+'</h2><p class="muted small" style="margin-top:0">Your workouts, body weight and photos are stored in your own Supabase project.</p>'+
   '<form id="authform"><div class="field"><label>Email</label><input class="in" id="au-email" type="email" autocomplete="email" required></div><div class="field" style="margin-top:10px"><label>Password</label><input class="in" id="au-pass" type="password" autocomplete="'+(up?'new-password':'current-password')+'" minlength="6" required></div>'+
   '<div id="au-msg" class="small" style="margin-top:10px;color:#f3c98a"></div><button class="btn pri block" type="submit" style="margin-top:12px;padding:12px">'+(up?'Create account':'Sign in')+'</button></form>'+
   '<p class="muted small" style="text-align:center;margin-bottom:0">'+(up?'Already have an account? <a href="#" data-act="authmode" data-m="signin" style="color:var(--accent)">Sign in</a>':'First time? <a href="#" data-act="authmode" data-m="signup" style="color:var(--accent)">Create your account</a>')+'</p></div>';
}
async function doAuth(){
  const email=$('#au-email').value.trim(), pass=$('#au-pass').value, msg=$('#au-msg');
  if(!email||pass.length<6){ msg.textContent='Enter your email and a password of at least 6 characters.'; return; }
  msg.textContent='…';
  try{
    if(S.authMode==='signup'){ const r=await store.signUp(email,pass); if(r.needsConfirm){ msg.textContent='Check your email and tap the confirmation link, then sign in here.'; S.authMode='signin'; return; } }
    else await store.signIn(email,pass);
  }catch(e){ msg.textContent=(e&&e.message)||'Something went wrong'; }
}
document.addEventListener('submit', ev=>{ if(ev.target.id==='authform'){ ev.preventDefault(); doAuth(); } });

async function boot(){
  render();
  if(!store.configured){ S.mode='noconfig'; render(); return; }
  store.onChange(()=>{ const u=store.currentUser(); const want=u?'app':'auth'; if(S.mode!==want){ S.mode=want; S.route={name:'log'}; S.draft=null; S.tdraft=null; closeSheet(); render(); } });
  try{ await store.initAuth(); }catch(e){ console.error(e); }
  S.mode = store.currentUser() ? 'app' : 'auth';
  refreshFromStore(); showStatus(); render();
}
boot();
