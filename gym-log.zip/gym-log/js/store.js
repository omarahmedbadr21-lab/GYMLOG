// Offline-first data layer on top of Supabase.
// - Every collection is kept in memory + localStorage, so the app opens and works without a connection.
// - Writes go into a persisted queue (one entry per record, latest wins) and are pushed when online.
// - A pull from Supabase replaces the local copy, except for records that still have unsent changes.
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config.js';

export const COLLS = ['workouts', 'templates', 'photos', 'bodyweight'];
const BUCKET = 'photos';

export const configured = !!(SUPABASE_URL && SUPABASE_ANON_KEY && !SUPABASE_URL.includes('YOUR_'));
export const sb = configured
  ? (globalThis.__GYMLOG_SUPABASE__ || createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true } }))
  : null;

let user = null;
let cache = emptyCache();
let queue = [];
let flushing = false, retryT = null;
let status = { state: 'idle', detail: '' };
const listeners = new Set();

function emptyCache() { const c = {}; COLLS.forEach(k => c[k] = {}); return c; }
const lsKey = k => 'gymlog:' + (user ? user.id : 'anon') + ':' + k;
function loadLocal() {
  cache = emptyCache(); queue = [];
  try {
    const c = JSON.parse(localStorage.getItem(lsKey('cache')) || 'null');
    if (c) COLLS.forEach(k => { cache[k] = c[k] || {}; });
    queue = JSON.parse(localStorage.getItem(lsKey('queue')) || '[]');
  } catch (e) { /* corrupted local copy: start clean, server copy will be pulled */ }
}
function saveLocal() {
  try {
    localStorage.setItem(lsKey('cache'), JSON.stringify(cache));
    localStorage.setItem(lsKey('queue'), JSON.stringify(queue));
  } catch (e) { setStatus('error', 'Local storage is full'); }
}
function emit() { listeners.forEach(fn => { try { fn(); } catch (e) { console.error(e); } }); }
function setStatus(state, detail = '') { status = { state, detail }; emit(); }

export const onChange = fn => { listeners.add(fn); return () => listeners.delete(fn); };
export const getStatus = () => ({ ...status, pending: queue.length, online: navigator.onLine });
export const currentUser = () => user;

/* ---------- auth ---------- */
export async function initAuth() {
  if (!sb) return null;
  const { data } = await sb.auth.getSession();
  await setUser(data.session ? data.session.user : null);
  sb.auth.onAuthStateChange((_ev, session) => {
    const u = session ? session.user : null;
    if ((u && u.id) !== (user && user.id)) setUser(u);
  });
  return user;
}
async function setUser(u) {
  user = u;
  loadLocal();
  emit();
  if (user) { await flush(); await pull(); }
}
export async function signIn(email, password) {
  const { error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw error;
}
export async function signUp(email, password) {
  const { data, error } = await sb.auth.signUp({ email, password });
  if (error) throw error;
  return { needsConfirm: !data.session };
}
export async function signOut() {
  if (queue.length) { await flush(); if (queue.length) throw new Error('unsynced'); }
  await sb.auth.signOut();
}

/* ---------- reads / writes ---------- */
export const rows = coll => Object.entries(cache[coll] || {}).map(([id, d]) => Object.assign({ id }, JSON.parse(JSON.stringify(d))));

export function put(coll, id, data) {
  const body = JSON.parse(JSON.stringify(data)); delete body.id;
  cache[coll][id] = body;
  enqueue({ op: 'upsert', coll, id });
}
export function del(coll, id) {
  delete cache[coll][id];
  enqueue({ op: 'delete', coll, id });
}
function enqueue(item) {
  queue = queue.filter(q => !(q.coll === item.coll && q.id === item.id));
  queue.push(item);
  saveLocal(); emit();
  clearTimeout(retryT); retryT = setTimeout(flush, 400);
}

export async function flush() {
  if (flushing || !user || !sb) return;
  if (!navigator.onLine) { if (queue.length) setStatus('offline'); return; }
  if (!queue.length) { setStatus('synced'); return; }
  flushing = true; setStatus('saving');
  try {
    while (queue.length) {
      const q = queue[0];
      if (q.op === 'upsert') {
        const d = cache[q.coll][q.id];
        if (d) {
          const { error } = await sb.from(q.coll).upsert(
            { user_id: user.id, id: q.id, data: d, updated_at: new Date().toISOString() },
            { onConflict: 'user_id,id' });
          if (error) throw error;
        }
      } else {
        const { error } = await sb.from(q.coll).delete().eq('id', q.id);
        if (error) throw error;
      }
      queue = queue.filter(x => x !== q); // a newer edit to the same record stays queued
      saveLocal();
    }
    setStatus('synced');
  } catch (e) {
    console.warn('sync failed', e);
    setStatus(navigator.onLine ? 'error' : 'offline', e && e.message || String(e));
    clearTimeout(retryT); retryT = setTimeout(flush, 15000);
  } finally { flushing = false; }
}

export async function pull() {
  if (!user || !sb || !navigator.onLine) return;
  try {
    for (const coll of COLLS) {
      const fresh = {};
      for (let from = 0; ; from += 1000) {
        const { data, error } = await sb.from(coll).select('id,data').order('id').range(from, from + 999);
        if (error) throw error;
        data.forEach(r => { fresh[r.id] = r.data; });
        if (data.length < 1000) break;
      }
      // unsent local changes win over the server copy
      queue.filter(q => q.coll === coll).forEach(q => {
        if (q.op === 'upsert' && cache[coll][q.id]) fresh[q.id] = cache[coll][q.id];
        if (q.op === 'delete') delete fresh[q.id];
      });
      cache[coll] = fresh;
    }
    saveLocal();
    setStatus(queue.length ? 'saving' : 'synced');
  } catch (e) {
    console.warn('pull failed', e);
    setStatus('error', e && e.message || String(e));
  }
}

/* ---------- photos ---------- */
const urlCache = new Map(); // path -> {url, exp}
export async function uploadPhoto(blob, id) {
  if (!navigator.onLine) throw new Error('offline');
  const path = user.id + '/' + id + '.jpg';
  const { error } = await sb.storage.from(BUCKET).upload(path, blob, { contentType: 'image/jpeg', upsert: true });
  if (error) throw error;
  return path;
}
export async function deletePhoto(path) {
  urlCache.delete(path);
  const { error } = await sb.storage.from(BUCKET).remove([path]);
  if (error) console.warn('photo delete failed', error);
}
export async function photoUrls(paths) {
  const now = Date.now(); const out = {}; const need = [];
  [...new Set(paths)].forEach(p => { const c = urlCache.get(p); if (c && c.exp > now) out[p] = c.url; else need.push(p); });
  if (need.length && navigator.onLine && sb) {
    const { data, error } = await sb.storage.from(BUCKET).createSignedUrls(need, 3600);
    if (!error && data) data.forEach(r => { if (r.signedUrl) { urlCache.set(r.path, { url: r.signedUrl, exp: now + 50 * 60 * 1000 }); out[r.path] = r.signedUrl; } });
  }
  return out;
}

/* keep in sync when the app comes back */
addEventListener('online', async () => { await flush(); await pull(); });
addEventListener('offline', () => { if (queue.length) setStatus('offline'); else emit(); });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && user) { flush().then(pull); } });
