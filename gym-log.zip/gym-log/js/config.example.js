// Copy this file to js/config.js for local development.
// On GitHub Pages, the deploy workflow writes js/config.js from the repository secrets
// SUPABASE_URL and SUPABASE_ANON_KEY, so you never commit real values.
// The anon key is designed to be public: Row Level Security in supabase/schema.sql
// is what keeps your data private.
export const SUPABASE_URL = 'https://YOUR_PROJECT_REF.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR_ANON_PUBLIC_KEY';
